"""Verify that this update only changes Reports and its dedicated API extension."""
import os, pathlib, zipfile, hashlib
root=pathlib.Path(os.environ.get('REPORT_PROJECT_ROOT',pathlib.Path(__file__).resolve().parents[1]))
original=pathlib.Path(os.environ['REPORT_ORIGINAL_ZIP'])
modified={'frontend/src/main.jsx','api/reports.php'}
checked=0
with zipfile.ZipFile(original) as archive:
    main_before=api_before=None
    for entry in archive.infolist():
        if entry.is_dir():continue
        name=entry.filename.removeprefix('SP-Manager-main/')
        if name.startswith('frontend/dist/'):continue  # compiled output is regenerated
        before=archive.read(entry)
        if name=='frontend/src/main.jsx':main_before=before
        if name=='api/reports.php':api_before=before
        if name in modified:continue
        after=root/name
        if name=='database/u729423317_SPCentral.sql' and not after.exists():continue  # reference data dump is deliberately omitted from distributable source
        assert after.is_file(),f'Original file missing: {name}'
        assert after.read_bytes()==before,f'Unrelated file changed: {name}'
        checked+=1
    assert main_before and api_before
    before=main_before.decode('utf-8');after=(root/'frontend/src/main.jsx').read_bytes().decode('utf-8')
    after=after.replace('import ReportingPage from "./reporting/reporting-page.jsx";\r\n','',1)
    start=after.index('function Reports(');end=after.index('function EndOfDay(',start)
    original_start=before.index('function Reports(');original_end=before.index('function EndOfDay(',original_start)
    after=after[:start]+before[original_start:original_end]+after[end:]
    previous='{page==="Reports"&&<Reports sales={sales} products={products} customers={customers} purchases={purchases} businessDay={businessDay} users={users} suppliers={suppliers} paymentTypes={paymentTypes}/>}'
    after=after.replace('{page==="Reports"&&<Reports activeUser={activeUser}/>}',previous,1)
    assert after==before,'main.jsx contains changes outside the Reports component/render/import'
    api=(root/'api/reports.php').read_bytes().decode('utf-8')
    start=api.index('// Reporting extension: legacy summary below remains unchanged.')
    end=api.index("$config = require __DIR__ . '/config.php';",start)
    restored=api[:start]+api[end:]
    assert restored.encode('utf-8')==api_before,'Legacy reports summary modified'
print(f'PASS: {checked} original source/static/API files unchanged.')
print('PASS: main.jsx changes limited to Reports import, component and render.')
print('PASS: POS, Dashboard, Login, Price Tag, HR, Booking, other screens and global CSS preserved.')
print('PASS: original reports.php summary restored byte-for-byte after removing the dispatch hook.')
