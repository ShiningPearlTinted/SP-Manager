import fs from 'node:fs';
import assert from 'node:assert/strict';
const output=process.env.REPORT_TEST_OUTPUT_DIR;assert(output,'REPORT_TEST_OUTPUT_DIR required.');
const f=JSON.parse(fs.readFileSync(output+'/fixtures.json','utf8'));
const base=process.env.REPORT_TEST_BASE||'http://127.0.0.1:8174';assert(['127.0.0.1','localhost'].includes(new URL(base).hostname),'Refusing remote API.');let count=0;
function check(value,label){assert(value,label);console.log('PASS: '+label);count++;}
async function call(action,options={}) {
  const params=new URLSearchParams({action,outlet_id:String(options.outlet??f.outlet),start:'2026-10-01',end:'2026-10-31',...options.query});
  const response=await fetch(base+'/'+(options.file||'reports.php')+'?'+params,{method:options.method||'GET',headers:options.actor===null?{}:{Authorization:'Bearer '+f.tokens[options.actor||'reporter']}});
  if(options.pdf)return {status:response.status,bytes:Buffer.from(await response.arrayBuffer()),type:response.headers.get('content-type')};
  return {status:response.status,data:await response.json()};
}
check((await call('report-catalog',{actor:null})).status===401,'anonymous report request rejected');
check((await call('report-catalog',{actor:'denied'})).status===403,'manageReports permission required');
check((await call('report-catalog',{outlet:f.other_outlet})).status===403,'unassigned outlet rejected');
check((await call('report-catalog',{actor:'admin',outlet:f.other_outlet})).status===403,'administrator still requires outlet assignment');
const catalog=await call('report-catalog');check(catalog.status===200&&catalog.data.reports.length===38,'report catalogue serves all 38 definitions');
const options=await call('report-options');check(options.status===200&&options.data.options.products.some(x=>Number(x.id)===f.product),'filter options load from authorized outlet');
for(const def of catalog.data.reports){const r=await call('run-report',{query:{report:def.id}});check(r.status===200&&r.data.ok,'HTTP report '+def.id);}
const selected=await call('run-report',{query:{report:'sales-products',product:String(f.product)}});check(selected.data.totals.gross==='28.62','HTTP product filter reconciles sale allocation and partial refund');
check((await call('run-report',{query:{report:'sales-products',terminal:String(f.terminal)}})).status===400,'inapplicable filter rejected over HTTP');
check((await call('run-report',{query:{report:'nonexistent'}})).status===404,'unknown report rejected');
check((await call('run-report',{query:{report:'sales-products',start:'2026-02-30'}})).status===400,'invalid report date rejected over HTTP');
check((await call('run-report',{query:{report:'sales-products','product[]':'1'}})).status===400,'array filter rejected without leaking query data');
check((await call('run-report',{method:'POST',query:{report:'sales-products'}})).status===405,'reporting endpoint is read-only');
const pdf=await call('report-pdf',{query:{report:'sales-products'},pdf:true});check(pdf.status===200&&pdf.type.startsWith('application/pdf')&&pdf.bytes.subarray(0,5).toString()==='%PDF-','authorized PDF export returns a real PDF');
fs.writeFileSync(output+'/http-report.pdf',pdf.bytes);
check((await call('report-pdf',{actor:'denied',query:{report:'sales-products'},pdf:true})).status===403,'PDF authorization matches report authorization');
check((await call('run-report',{file:'reporting-dispatch.php',actor:'denied',query:{report:'sales-products'}})).status===403,'direct extension URL does not bypass report permission');
const summary=await call('summary',{actor:'admin'});check(summary.status===200&&summary.data.reports_version==='V1'&&summary.data.sql_source,'legacy summary response retained');
console.log(`RESULT: ${count} HTTP checks passed.`);
