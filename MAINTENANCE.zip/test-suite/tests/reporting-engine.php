<?php
declare(strict_types=1);
$api=getenv('REPORT_TEST_API_DIR')?:'';$output=getenv('REPORT_TEST_OUTPUT_DIR')?:'';
if($api===''||$output===''||!is_file($api.'/config.php'))throw new RuntimeException('Set isolated REPORT_TEST_API_DIR and REPORT_TEST_OUTPUT_DIR.');
$config=require $api.'/config.php';$cfg=$config['db']??[];
if(!in_array($cfg['host']??'',['127.0.0.1','localhost'],true)||!str_starts_with($cfg['name']??'','spm_reporting_test'))throw new RuntimeException('Refusing production or non-local database.');
if(!is_dir($output))mkdir($output,0700,true);
define('SP_MANAGER_CLI',true);
require $api.'/security.php';
require dirname(__DIR__).'/api/reporting-lib.php';
require dirname(__DIR__).'/api/reporting-pdf.php';
$db=spApiDatabase();if(!str_starts_with((string)$db->query('SELECT DATABASE()')->fetchColumn(),'spm_reporting_test'))throw new RuntimeException('Test DB required.');
$db->exec("SET time_zone='+08:00'");date_default_timezone_set('Asia/Kuala_Lumpur');$checks=0;
function check(bool $condition,string $label):void {global $checks;if(!$condition)throw new RuntimeException('FAIL: '.$label);echo "PASS: $label\n";$checks++;}
function rejected(callable $fn,int $status,string $label):void {try{$fn();}catch(ReportingError $e){check($e->status===$status,$label);return;}throw new RuntimeException('Expected rejection: '.$label);}
function insertRowTest(PDO $db,string $table,array $row):int {$q=$db->prepare('INSERT INTO '.$table.' (`'.implode('`,`',array_keys($row)).'`) VALUES('.implode(',',array_fill(0,count($row),'?')).')');$q->execute(array_values($row));return(int)$db->lastInsertId();}
function fingerprint(PDO $db):array {$out=[];foreach($db->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN) as $t)$out[$t]=$db->query('CHECKSUM TABLE `'.$t.'`')->fetch()['Checksum'];return $out;}
check(count(rpCatalog())===38,'38 Aronium-style reports registered');
check(rpMoney('12.345')===1235&&rpMoney('-12.345')===-1235,'money rounding is symmetric');
check(rpDecimal(-1235)==='-12.35','decimal monetary formatting');
check(array_sum(rpAllocate(100,[1,1,1]))===100&&rpAllocate(100,[1,1,1])===[34,33,33],'cent-exact allocation with stable remainder');
check(array_sum(rpAllocate(-100,[1,1,1]))===-100,'negative allocation reconciles');
check(rpAllocate(9000000000000,[3000000000000,3000000000000,3000000000000])===[3000000000000,3000000000000,3000000000000],'large monetary allocations avoid floating-point overflow');
check(rpAllocate(100,[0,0])===[100,0],'zero-weight documents retain their recorded total');
rejected(fn()=>rpDate('2026-02-29'),400,'invalid calendar date rejected');
rejected(fn()=>rpId(['1']),400,'array filter rejected');
rejected(fn()=>new ReportingEngine($db,1,['start'=>'2026-10-31','end'=>'2026-10-01']),400,'reversed range rejected');
$before=fingerprint($db);
foreach(rpCatalog() as $def){$r=(new ReportingEngine($db,1,['start'=>'2026-01-01','end'=>'2026-12-31']))->run($def['id']);check($r['ok']&&is_array($r['rows'])&&count($r['columns'])>0,'supplied SQL supports '.$def['id']);}
check($before===fingerprint($db),'all reports leave every existing table checksum unchanged');
$a=insertRowTest($db,'outlets',['outlet_code'=>'REPORT_A','outlet_name'=>'Report test A','active'=>1]);$b=insertRowTest($db,'outlets',['outlet_code'=>'REPORT_B','outlet_name'=>'Report test B','active'=>1]);
insertRowTest($db,'company_settings',['outlet_id'=>$a,'company_name'=>'SP-Manager Test Company','street_name'=>'Test Street','city'=>'Test City','currency_code'=>'MYR']);
$role=(int)$db->query("SELECT id FROM roles WHERE role_name='Administrator' LIMIT 1")->fetchColumn();$cashier=(int)$db->query("SELECT id FROM roles WHERE role_name<>'Administrator' LIMIT 1")->fetchColumn();
$users=[];foreach(['admin'=>[$role,['manageReports'=>true]],'reporter'=>[$cashier,['manageReports'=>true]],'denied'=>[$cashier,[]]] as $name=>[$rid,$permissions]){$users[$name]=insertRowTest($db,'users',['outlet_id'=>$a,'name'=>'Report test '.$name,'username'=>'__report_test_'.$name,'password_hash'=>password_hash('Local-report-test-2026!',PASSWORD_DEFAULT),'role_id'=>$rid,'permissions_json'=>json_encode($permissions)]);insertRowTest($db,'user_outlets',['user_id'=>$users[$name],'outlet_id'=>$a,'active'=>1,'is_default'=>1]);}
$parent=insertRowTest($db,'product_groups',['outlet_id'=>$a,'group_name'=>'Test Parent']);$child=insertRowTest($db,'product_groups',['outlet_id'=>$a,'parent_id'=>$parent,'group_name'=>'Test Child']);
$p1=insertRowTest($db,'products',['outlet_id'=>$a,'group_id'=>$child,'sku'=>'REPORT-P1','product_name'=>'Report test product one','selling_price'=>'30.00','cost_price'=>'999.00']);
$p2=insertRowTest($db,'products',['outlet_id'=>$a,'group_id'=>$parent,'sku'=>'REPORT-P2','product_name'=>'Report test product two','selling_price'=>'40.00','cost_price'=>'888.00']);
foreach([$p1,$p2] as $pid)insertRowTest($db,'product_outlets',['product_id'=>$pid,'outlet_id'=>$a,'stock_qty'=>'2','min_stock'=>'3','preferred_quantity'=>'8','active'=>1]);
$customer=insertRowTest($db,'customers',['outlet_id'=>$a,'name'=>'Report test customer']);$supplier=insertRowTest($db,'suppliers',['outlet_id'=>$a,'supplier_name'=>'Report test supplier']);
$sale=insertRowTest($db,'sales',['outlet_id'=>$a,'sale_no'=>'REPORT-S1','sale_date'=>'2026-10-15 10:30:00','customer_id'=>$customer,'subtotal'=>'100.00','discount'=>'10.00','tax'=>'5.40','total'=>'95.40','payment_status'=>'PARTIAL','status'=>'COMPLETED','created_by'=>$users['reporter'],'order_name'=>'Table 5']);
foreach([[$p1,'2','30.00','60.00','20.00'],[$p2,'1','40.00','40.00',null]] as [$pid,$qty,$price,$total,$cost])insertRowTest($db,'sale_items',['sale_id'=>$sale,'product_id'=>$pid,'product_name'=>'Historical product '.$pid,'quantity'=>$qty,'unit_price'=>$price,'line_total'=>$total,'cost_snapshot'=>$cost]);
insertRowTest($db,'sale_payments',['sale_id'=>$sale,'payment_type_name'=>'Cash','amount'=>'50.00','created_at'=>'2026-10-15 10:30:00']);
$other=insertRowTest($db,'sales',['outlet_id'=>$b,'sale_no'=>'REPORT-SECRET','sale_date'=>'2026-10-15 10:30:00','subtotal'=>'9999.00','total'=>'9999.00']);insertRowTest($db,'sale_items',['sale_id'=>$other,'product_id'=>$p1,'product_name'=>'Other outlet secret','quantity'=>'1','unit_price'=>'9999.00','line_total'=>'9999.00','cost_snapshot'=>'1.00']);
$void=insertRowTest($db,'sales',['outlet_id'=>$a,'sale_no'=>'REPORT-VOID','sale_date'=>'2026-10-15 11:30:00','subtotal'=>'500.00','total'=>'500.00','status'=>'VOIDED','created_by'=>$users['reporter']]);insertRowTest($db,'sale_items',['sale_id'=>$void,'product_id'=>$p1,'product_name'=>'Voided product','quantity'=>'1','unit_price'=>'500.00','line_total'=>'500.00','cost_snapshot'=>'1.00']);
$terminal=insertRowTest($db,'terminals',['outlet_id'=>$a,'terminal_id'=>'REPORT-REG','terminal_name'=>'Report test register','terminal_type'=>'PC POS']);insertRowTest($db,'register_sessions',['outlet_id'=>$a,'terminal_id'=>$terminal,'opened_by'=>$users['reporter'],'opened_at'=>'2026-10-15 08:00:00','opening_cash'=>'100.00']);
$purchase=insertRowTest($db,'purchases',['outlet_id'=>$a,'supplier_id'=>$supplier,'purchase_no'=>'REPORT-PUR1','purchase_date'=>'2026-10-15 09:00:00','subtotal'=>'40.00','total'=>'40.00','created_by'=>$users['reporter'],'data_json'=>json_encode(['paid'=>false,'payments'=>[['payment'=>'Bank','amount'=>'10.00']]])]);insertRowTest($db,'purchase_items',['purchase_id'=>$purchase,'product_id'=>$p1,'quantity'=>'2','unit_cost'=>'20.00','total'=>'40.00','data_json'=>json_encode(['discount'=>'1.50','expirationDate'=>'2027-03-01'])]);
$unknown=insertRowTest($db,'purchases',['outlet_id'=>$a,'supplier_id'=>$supplier,'purchase_no'=>'REPORT-UNKNOWN','purchase_date'=>'2026-10-15 09:05:00','subtotal'=>'20.00','total'=>'20.00']);insertRowTest($db,'purchase_items',['purchase_id'=>$unknown,'product_id'=>$p2,'quantity'=>'1','unit_cost'=>'20.00','total'=>'20.00']);
foreach([['LOSS','-1'],['PURCHASE_RETURN','-2'],['SALE','-3']] as [$type,$qty])insertRowTest($db,'stock_movements',['outlet_id'=>$a,'product_id'=>$p1,'movement_type'=>$type,'quantity'=>$qty,'created_at'=>'2026-10-15 12:00:00','created_by'=>$users['reporter']]);
$period=['start'=>'2026-10-01','end'=>'2026-10-31'];$engine=fn($extra=[])=>new ReportingEngine($db,$a,[...$period,...$extra]);
$r=$engine()->run('sales-products');check($r['totals']['gross']==='95.40'&&$r['totals']['net']==='90.00','sale item totals reconcile to header without other outlet or void');
$r=$engine(['product'=>$p1])->run('sales-products');check($r['totals']['gross']==='57.24'&&$r['totals']['net']==='54.00'&&$r['totals']['discount']==='6.00','product filter uses allocated amounts rather than full document');
$r=$engine(['group'=>$parent,'include_subgroups'=>'0'])->run('sales-products');check(count($r['rows'])===1&&$r['totals']['gross']==='38.16','group filter excludes child when disabled');
$r=$engine(['group'=>$parent,'include_subgroups'=>'1'])->run('sales-products');check(count($r['rows'])===2&&$r['totals']['gross']==='95.40','group filter includes descendants');
$r=$engine()->run('sales-profit');check($r['totals']['profit']===null&&$r['totals']['cost']===null,'missing historical cost remains unknown');
$r=$engine(['product'=>$p1])->run('sales-profit');check($r['totals']['cost']==='40.00'&&$r['totals']['profit']==='14.00','profit uses historical snapshot instead of current master cost');
$r=$engine()->run('sales-unpaid');check($r['totals']['balance']==='45.40','unpaid sales use recorded payments, not payment status label');
$r=$engine()->run('sales-payment-types');check($r['totals']['amount']==='50.00','tenders do not join/multiply item rows');
$r=$engine()->run('sales-voided-items');check($r['totals']['gross']==='500.00','voided items have dedicated report');
$r=$engine(['terminal'=>$terminal])->run('sales-starting-cash');check($r['totals']['amount']==='100.00','starting cash register filter');
rejected(fn()=>$engine(['terminal'=>$terminal])->run('sales-products'),400,'cash register filter rejected where linkage is unavailable');
$r=$engine()->run('purchase-unpaid');check($r['totals']['balance']===null&&count($r['rows'])===2,'unknown purchase payment data does not become a false paid/unpaid balance');
$r=(new ReportingEngine($db,$a,['start'=>'2027-03-01','end'=>'2027-03-31']))->run('purchase-expiration-date');check(count($r['rows'])===1&&$r['rows'][0]['expiry']==='2027-03-01','expiration filters the expiry date even when purchase predates the range');
$r=$engine()->run('loss-damage-products');check($r['totals']['quantity']===-1.0,'loss and damage use typed stock records');
$r=$engine()->run('stock-return-products');check($r['totals']['quantity']===-2.0,'stock return uses typed stock records');
$r=$engine()->run('stock-control-reorder');check($r['totals']['reorder']===12.0,'stock reorder uses outlet preferred quantity');
$refund=insertRowTest($db,'sale_refunds',['outlet_id'=>$a,'original_sale_id'=>$sale,'refund_no'=>'REPORT-REF1','refund_date'=>'2026-10-16 10:00:00','amount'=>'28.62','created_by'=>$users['reporter']]);
$saleItem=(int)$db->query('SELECT id FROM sale_items WHERE sale_id='.$sale.' AND product_id='.$p1)->fetchColumn();insertRowTest($db,'sale_refund_items',['refund_id'=>$refund,'sale_item_id'=>$saleItem,'product_id'=>$p1,'quantity'=>'1','amount'=>'30.00']);
$r=$engine()->run('sales-products');check($r['totals']['gross']==='66.78'&&$r['totals']['net']==='63.00','sales aggregate nets partial refunds on refund date');
$r=$engine(['product'=>$p1])->run('sales-profit');check($r['totals']['gross']==='28.62'&&$r['totals']['cost']==='20.00'&&$r['totals']['profit']==='7.00','partial refund reverses only refunded quantity historical cost');
$r=(new ReportingEngine($db,$a,['start'=>'2026-10-16','end'=>'2026-10-16']))->run('sales-products');check($r['totals']['gross']==='-28.62','refund period works when original sale is outside date range');
$r=$engine()->run('sales-hourly');check($r['totals']['gross']==='95.40','hourly gross sales excludes separate return documents per original template');
$r=$engine()->run('sales-payment-types');check($r['totals']['amount']==='50.00','refund cash tender is not guessed from original payment');
$r=$engine(['product'=>$p1])->run('sales-profit');$r['applied_filter_labels']=[];$r['company']['company_name']='测试';rejected(fn()=>rpPdf($r),422,'PDF rejects unsupported font characters instead of altering names');
$before=fingerprint($db);foreach(rpCatalog() as $def)$engine()->run($def['id']);check($before===fingerprint($db),'fixture report suite is read-only');
$tokens=[];foreach($users as $key=>$uid)$tokens[$key]=spIssueApiToken($uid);
file_put_contents($output.'/fixtures.json',json_encode(['outlet'=>$a,'other_outlet'=>$b,'tokens'=>$tokens,'users'=>$users,'product'=>$p1,'group'=>$parent,'terminal'=>$terminal,'sale'=>$sale,'customer'=>$customer,'supplier'=>$supplier],JSON_THROW_ON_ERROR));
$sample=$engine()->run('sales-item-list');$sample['applied_filter_labels']=[];
file_put_contents($output.'/sample-report.pdf',rpPdf($sample));
// Multi-page fixture validates repeated headings, totals and footers.
$sample['rows']=array_merge(...array_fill(0,70,$sample['rows']));$sample['row_count']=count($sample['rows']);file_put_contents($output.'/sample-multipage.pdf',rpPdf($sample));
echo "RESULT: $checks checks passed.\n";
